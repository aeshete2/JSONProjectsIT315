//
//  DCTouristSite.swift
//  DCTouristSite-AE
//
//  Created by user227538 on 10/24/22.
//

import Foundation
import UIKit
class DCTouristSite {
    var TouristSiteName = ""
    var TouristSiteDescription = ""
    var TouristSiteAddress = ""
    var TouristSiteOperationalHours = ""
    var TouristSitePhone = ""
    var TouristSiteArea = ""
    var TouristSitePhoto = ""
    var TouristSiteWebsite = ""
    var TouristSiteLatitude = 0.0
    var TouristSiteLongitude = 0.0

}
